package com.booking.service;

public class ValidationService {
    public static void validateInput(){

    }

    public static void validateCustomerId(){

    }
}
